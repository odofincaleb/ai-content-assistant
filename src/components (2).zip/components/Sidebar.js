import React, { useState } from 'react';
import './Sidebar.css';

const scriptsSubmenus = [
  'Advertisement',
  'Articles And Blogs',
  'Customer Service',
  'Ebook',
  'Ecommerce',
  'Emails',
  'Letters',
  'Marketing',
  'Podcast',
  'Press Release',
  'Research',
  'Reviews',
  'Rewriter',
  'Seo',
  'Social Media',
  'Video Scripts',
  'Website Copy',
];

const navItems = [
  { label: 'Scripts', hasSubmenu: true },
  { label: 'Script Editor' },
  { label: 'Text to Speech' },
  { label: 'Humanizer' },
  { label: 'Tutorials' },
  { label: 'Help' },
  { label: 'Settings' },
  { label: 'Close' },
];

function Sidebar({ activeMenu, onMenuSelect }) {
  const [scriptsOpen, setScriptsOpen] = useState(false);

  const handleMenuClick = (item) => {
    if (item === 'Scripts') {
      setScriptsOpen((open) => !open);
    } else {
      setScriptsOpen(false);
      onMenuSelect(item);
    }
    if (item === 'Scripts') {
      onMenuSelect('Scripts');
    }
  };

  return (
    <div className="sidebar">
      <div className="sidebar-title">fiddyscript</div>
      <ul className="sidebar-nav">
        {navItems.map(item => (
          <React.Fragment key={item.label}>
            <li
              className={activeMenu === item.label ? 'active' : ''}
              onClick={() => handleMenuClick(item.label)}
            >
              {item.label}
            </li>
            {item.hasSubmenu && scriptsOpen && (
              <ul className="sidebar-submenu">
                {scriptsSubmenus.map(sub => (
                  <li
                    key={sub}
                    className={activeMenu === sub ? 'active' : ''}
                    onClick={() => onMenuSelect(sub)}
                  >
                    {sub}
                  </li>
                ))}
              </ul>
            )}
          </React.Fragment>
        ))}
      </ul>
    </div>
  );
}

export default Sidebar; 